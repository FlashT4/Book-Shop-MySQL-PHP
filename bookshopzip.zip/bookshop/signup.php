<?php
    include "config.php";



    if (isset($_POST['uname']) && isset($_POST['password']) && isset($_POST['email']) && isset($_POST['name']) ) {

        function validate($data){
           $data = trim($data);
           $data = stripslashes($data);
           $data = htmlspecialchars($data);
           return $data;
        }
    
        $name = validate($_POST['name']);
        $uname = validate($_POST['uname']);
        $email = validate($_POST['email']);
        $pass = validate($_POST['password']);
    
        if (empty($uname)) {
            header("Location: register.php?error=User Name is required");
            exit();
        }else if(empty($pass)){
            header("Location: register.php?error=Password is required");
            exit();
        }else if(empty($email)){
            header("Location: register.php?error=E-mail is required");
            exit();
        }
        else if(empty($name)){
            header("Location: register.php?error=Name is required");
            exit();
        }else{
            $sql = "INSERT INTO users values( '$name', '$email','$uname','$pass')";
    
            $result = mysqli_query($conn, $sql);
    
            echo '<script type="text/javascript">'; 
            echo 'alert("You have been Registered succesfully!");';
            echo 'window.location.href = "index.php";';
            echo '</script>';
        }
        
    }else{
        header("Location: register.php");
        exit();
    }





?>
