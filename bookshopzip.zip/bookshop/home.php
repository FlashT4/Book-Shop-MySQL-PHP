<?php
session_start();
include "config.php";

$sql = "SELECT * FROM product";
$all_products = $conn->query(($sql));
?>


<!DOCTYPE html>
<html lang="en">

<head>
     <title>Dashboard</title>
     <link rel="stylesheet" href="hstyle.css">
</head>

<body>
     <?php include "header.php" ?>


     <main class="grid">
          <?php
          while ($row = mysqli_fetch_assoc($all_products)) {
          ?>

               <div class="card">
                    <form action="managecart.php" method="post">

                         <img src="<?php echo $row["product_image"]; ?>" alt="" style="width:100%">

                         <div class="text">
                              <h2><?php echo $row["product_name"]; ?> &#169;</h2>
                              <h2>Rs. <?php echo $row["product_price"]; ?></h2>

                              <input type="hidden" name="product_id" value=" <?php echo  $row["product_id"]; ?>">

                              <!-- <input type="hidden" name="product_name" value =" <?php echo  $row["product_name"]; ?>" >
                              <input type="hidden" name="product_price" value =" <?php echo  $row["product_price"]; ?>" > -->

                              <button type="submit" name="add-to-cart">
                                   <span id="btn" onclick="click()">Add to Cart</span>
                              </button>


                         </div>
                    </form>
               </div>

          <?php } ?>
     </main>


</body>

</html>