<?php
include "config.php";
session_start();

// add to cart logic
if (isset($_POST['add-to-cart'])) {

  if (isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];

    $sql = "SELECT * FROM cart WHERE book_id='$product_id'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) === 1) {
      $sql = "UPDATE cart SET quantity = quantity + 1 WHERE book_id = '$product_id'";
      $result = mysqli_query($conn, $sql);
      $sql = "UPDATE cart SET Total_price = book_price * quantity  WHERE book_id = '$product_id'";
      $result = mysqli_query($conn, $sql);
    } 
    else {
      $sql = "INSERT INTO cart (book_id, book_image, book_name, book_price) SELECT * FROM product WHERE product_id='$product_id' ";
      $result = mysqli_query($conn, $sql);
    }

    header(("location: home.php"));
  }
}

//remove from cart logic

if (isset($_POST['remove-from-cart'])) {
  if (isset($_POST['book_id'])) {
    $book_id = $_POST['book_id'];
    $sql = "DELETE FROM cart WHERE  book_id='$book_id'";
    $result = mysqli_query($conn, $sql);
    header("Location: cart.php");
  }
}

/* 
if (isset($_POST['delete-all-cart'])) {
    $book_id = $_POST['book_id'];
    $sql = "TRUNCATE TABLE cart";
    $result = mysqli_query($conn, $sql);
    header("Location: cart.php");
} */

?>