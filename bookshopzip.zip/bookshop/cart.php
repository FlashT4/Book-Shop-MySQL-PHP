<?php
session_start();
include "config.php";

$sql = "SELECT * FROM cart";
$all_products = $conn->query(($sql));
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <title>Cart</title>
    <link rel="stylesheet" href="hstyle.css">
    <link rel="stylesheet" href="cartstyle.css">
</head>

<body>
<?php include "header.php" ?>


    <table class="wp-table">
        <thead style="text-align: center">
            <!-- <th>Sr No.</th> -->
            <th>Image</th>
            <th>Book Name</th>
            <th>Quantity</th>
            <th>Price </th>
            <th>Remove</th>
        </thead>
        <?php
        while ($row = mysqli_fetch_assoc($all_products)) {
        ?>
            <tbody>
                <form method="post" action="managecart.php">
                    <!-- <td><?php echo $row["srno"]; ?></td> -->
                    <td class="im"><img src="<?php echo $row["book_image"]; ?>"></td>
                    <td><?php echo $row["book_name"]; ?></td>
                    <td><?php echo $row["quantity"]; ?></td>
                    <td><?php echo $row["Total_price"]; ?></td>
                    <input type="hidden" name="book_id" value=" <?php echo  $row["book_id"]; ?>">
                    <td><button class="remove-cart" name="remove-from-cart">Remove</button></td>
                </form>
                <form action="managecart.php" method="post"></form>
            </tbody>
        <?php } ?>
    </table>
    <div class="ta">

        <div class="total">
            Total Amount:

            <?php
            $sql1 = "SELECT  SUM(Total_price) as sum from cart";
            $result = $conn->query($sql1);

            while ($row = mysqli_fetch_array($result)) {
                echo  $row['sum'];
            }

            ?>
            <div class="payment">
                <form action="payment.php">
                    <button class="pay">Proceed to Pay</button>
                </form>
            </div>
        </div>
    </div>


</body>

</html>