<?php
session_start();
include "config.php";

$sql = "SELECT * FROM cart";
$all_products = $conn->query(($sql));
?>


<?php include "header.php" ?>
<html>

<head>
    <title>Invoice</title>
    <link rel="stylesheet" href="paystyle.css">
</head>

<body>
    <main>
        <header>
            <h1>Invoice</h1>
        </header>
        <article>


            <table class="inventory">
                <thead>
                    <tr>
                        <th>Book</th>
                        <th>Quantity</span></th>
                        <th>Price</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($all_products)) { ?>
                        <tr>
                            <td> ₹ <?php echo $row["book_name"]; ?> </td>
                            <td> ₹ <?php echo $row["quantity"]; ?> </td>
                            <td> ₹ <?php echo $row["Total_price"]; ?> </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <table class="balance">
                <tr>
                    <th>Total</th>
                    <td>₹
                        <?php
                        $sql1 = "SELECT  SUM(Total_price) as sum from cart";
                        $result = $conn->query($sql1);

                        while ($row = mysqli_fetch_array($result)) {
                            echo  $row['sum'];
                        }

                        ?>
                    </td>
                </tr>
            </table>
        </article>
    </main>

</body>

</html>