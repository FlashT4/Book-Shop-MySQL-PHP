<!DOCTYPE html>
<html>
    <head>
        <title>REGISTRATION</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
     <form action="signup.php" method="post">
     	<h2>REGISTRATION</h2>

     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
     	<label>Name</label>

     	<input type="text" name="name" placeholder="Name"><br>
     	
         <label>E-mail</label>
     	<input type="email" name="email" placeholder="E-mail"><br>
         
         <label>User Name</label>
          <input type="text" name="uname" placeholder="User Name"><br>
          
     	<label>Password</label>
     	<input type="password" name="password" placeholder="Password"><br>

     	<button type="submit">Sign Up</button>
     </form>
</body>
</html>