<!DOCTYPE html>
<html lang="en">

<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="headerstyle.css">
</head>

<body>
    <div class="header">
        <a href="home.php" class="logo">Book Store</a>
        <div class="header-right">
            <a class="active" href="home.php">Home</a>
            <!-- <a href="#contact">Contact</a> -->
            <a href="cart.php"> cart </i></a>
            <a href="index.php">Logout</a>
        </div>
    </div>
</body>

</html>