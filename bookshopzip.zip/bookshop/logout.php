<?php
session_start();

$sql = "TRUNCATE TABLE cart ";
$result = mysqli_query($conn, $sql);




session_unset();
session_destroy();

header("Location: index.php");


?>